rootProject.name = "apk-patcher"
